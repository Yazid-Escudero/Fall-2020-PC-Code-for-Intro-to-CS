//Author: Yazid Escudero

Notes:
*The submitted source code, as expected, should compile. However, the only roadblock to testing functionality is the address of the spotifydatabase.txt file. 

Inside the source code, find the creation of the file instance (just one) and replace the address with the address of your computer's location of the text database. 
